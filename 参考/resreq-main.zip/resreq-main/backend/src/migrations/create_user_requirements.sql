CREATE TABLE IF NOT EXISTS requirement_categories (
  id INT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
  parent_id INT NULL COMMENT '父分类ID，顶级分类为NULL',
  name VARCHAR(200) NOT NULL COMMENT '分类名称',
  description TEXT COMMENT '分类描述',
  reference TEXT COMMENT '参考信息或链接',
  level TINYINT NOT NULL COMMENT '层级：1大类、2小类、3问题项',
  sort_order INT DEFAULT 0 COMMENT '排序序号',
  is_active TINYINT DEFAULT 1 COMMENT '是否启用：1启用、0禁用',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  INDEX idx_parent_sort (parent_id, sort_order),
  INDEX idx_level (level),
  FOREIGN KEY (parent_id) REFERENCES requirement_categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='需求分类与问题项配置';

CREATE TABLE IF NOT EXISTS user_requirements (
  id INT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
  title VARCHAR(200) NOT NULL COMMENT '需求标题',
  applicant_id INT NOT NULL COMMENT '申请人ID',
  applicant_name VARCHAR(100) NOT NULL COMMENT '申请人姓名',
  status VARCHAR(50) DEFAULT 'active' COMMENT '状态：active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  INDEX idx_applicant (applicant_id),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户需求单';

CREATE TABLE IF NOT EXISTS requirement_answers (
  id INT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
  requirement_id INT NOT NULL COMMENT '需求单ID，关联user_requirements',
  category_id INT NOT NULL COMMENT '分类ID，关联requirement_categories',
  answer_text TEXT COMMENT '答案内容',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  UNIQUE KEY uk_requirement_category (requirement_id, category_id),
  FOREIGN KEY (requirement_id) REFERENCES user_requirements(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES requirement_categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户需求答案';
