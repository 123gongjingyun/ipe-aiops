-- 需求分类与问题项初始化数据
-- 注意：请根据实际《资源申请用户需求.xlsx》内容替换以下示例数据

-- 大类
INSERT INTO requirement_categories (parent_id, name, description, reference, level, sort_order) VALUES
(NULL, '1、背景', NULL, NULL, 1, 1),
(NULL, '2、用户相关', NULL, NULL, 1, 2),
(NULL, '3、系统相关', NULL, NULL, 1, 3);

-- 小类（假设大类 ID 为 1、2、3，实际 ID 以执行后的自增 ID 为准）
-- 请根据实际业务需求调整 parent_id
INSERT INTO requirement_categories (parent_id, name, description, reference, level, sort_order) VALUES
(1, '项目背景', NULL, NULL, 2, 1),
(2, '用户群体', NULL, NULL, 2, 1),
(3, '系统功能', NULL, NULL, 2, 1);

-- 问题项（假设小类 ID 为 4、5、6，实际 ID 以执行后的自增 ID 为准）
INSERT INTO requirement_categories (parent_id, name, description, reference, level, sort_order) VALUES
(4, '项目目标', '请描述本项目的业务目标和预期效果', '示例：提升用户体验，支持新车型上市', 3, 1),
(5, '用户类型', '系统的主要使用人员是哪些？', '示例：互联网用户、经销店人员、内部运营', 3, 1),
(6, '核心功能', '请描述系统需要实现的核心功能', '示例：用户注册、订单管理、报表统计', 3, 1);
